import 'package:flutter/material.dart';
import 'package:recipes/recipe.dart';
import 'recipe_detail.dart';


void main() {
  runApp(const RecipesApp());
}

class RecipesApp extends StatelessWidget {
  const RecipesApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Recipe Calculator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 174, 204, 93)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Recipe Calculator'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  

  @override
  Widget build(BuildContext context) {
    //1
    return Scaffold(
      //2
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      //3
      body: SafeArea(
        child: ListView.builder(
          itemCount: Recipe.samples.length,
          itemBuilder: (BuildContext, int index) {
            return GestureDetector (
              onTap: () {
                Navigator.push (
                  context,
                  MaterialPageRoute(
                    builder: (context){
                      //TODO: Replace return with return Recipe Detail
                      return RecipeDetail(recipe:Recipe.samples[index]);
                    },
                  ),
                );
              },
              child: buildRecipeCard(Recipe.samples[index]),
            );
          }
          )
      ),
    );
  }
  //TODO: Add buildRecipeCard() here
  Widget buildRecipeCard(Recipe recipe) {
    //1
    return Card (
      elevation:5.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30.0)),
      child:Padding(
        padding: const EdgeInsets.all(16.0),

        child: Column (
          children: <Widget>[
            Image (
              image: AssetImage (recipe.imageUrl),
              fit: BoxFit.cover,
              height: 200,
              width: 200,
              ),
        
            const SizedBox (
             height: 14.0,
            ),

            Text (
              recipe.label,
              style: const TextStyle(
                fontSize: 30.0,
                fontWeight: FontWeight.w700,
                fontFamily: 'Palatino',
              ),
            )
          ],
        ),
      ),
    );
  }

}
